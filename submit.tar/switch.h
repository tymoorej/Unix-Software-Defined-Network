#ifndef SWITCH_INCLUDE
#define SWITCH_INCLUDE

#include "includes.h"

void switch_init(int n, string traffic_file, int left, int right, int ip_range_lo, int ip_range_hi);

#endif