#ifndef CONTROLLER_INCLUDE
#define CONTROLLER_INCLUDE

#include "includes.h"

void controller_init(int num_of_switches);

#endif